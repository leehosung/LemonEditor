
 /* Decleare Visible Fn */ 

 /* Decleare Frame Fn */ 

$(document).ready(function(){
console.log('ready : iuevent.js')	

	

 /* initialize fn */ 
	

});