from django.conf.urls import patterns, include, url

from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    url(r'^$', 'galleryApp.views.index', name='index'),
    url(r'^index$', 'galleryApp.views.index', name='index'),
    url(r'^register$', 'galleryApp.views.register', name='register'),
    url(r'^Gallery$', 'galleryApp.views.gallery', name='gallery'),
    url(r'^Gallery/(\d+)$', 'galleryApp.views.gallery', name='gallery'),
    url(r'^Contact$', 'galleryApp.views.contact', name='contact'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
)
